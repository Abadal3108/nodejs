## Estructura archivos y carpetas node.js

- Controllers: contiene los controladores de la aplicación, que manejan la lógica de negocios y envían respuestas a las solicitudes HTTP.

- config: contiene la configuración de la base de datos y las funciones para interactuar con ella en el fichero db.js.

- .env: contiene las variables de entorno de la aplicación, como credenciales de base de datos, puertos, claves API, etc.

- public: contiene archivos estáticos que son accesibles públicamente, como imágenes, hojas de estilo CSS, etc. En este caso, css es una subcarpeta que contiene style.css.

- routes.js define las rutas de la aplicación y asigna controladores a cada ruta.

- views contiene archivos EJS que son las plantillas de la aplicación y que describen la vista que se muestra al usuario.