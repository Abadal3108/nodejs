const bcrypt = require("bcryptjs");
const conexion = require("../config/db.js");



/*Función para la página principal

index: Renderiza la página principal.

getLogin: Renderiza la página de inicio de sesión.

postAuth: Verifica si el usuario y la contraseña proporcionados son válidos.

register: Renderiza la página de registro de usuario.

registerPost: Procesa la solicitud de registro de usuario y almacena la información del usuario en una base de datos.*/

exports.index = (req, res) => {
  res.render("index", { msg: "alex" });
};

exports.getLogin = (req, res) => {
  res.render("login", { msg: "NPODE" });
};

exports.postAuth = async (req, res) => {
  let user = req.body.user;
  let pass = req.body.pass;

  if (!user || !pass) {
    return res.status(400).send("Debe proporcionar usuario y contraseña.");
  }
/*Realizamos una consulta a la base de datos para obtener los datos de un usuario específico. 
El nombre de usuario se proporciona como un parámetro en la consulta. Si no hay errores en la consulta y el resultado 
tiene una longitud mayor que cero, el código entonces compara la contraseña proporcionada con la contraseña almacenada en la base de datos utilizando la función bcrypt.compare(). 
Si la comparación falla, se envía una respuesta HTTP 401 con un mensaje "Usuario y/o contraseña incorrecta". 
Si la comparación es correcta, se envía una respuesta con el mensaje "Disfruta de tu sesión!".
*/
  conexion.query(
    "SELECT * FROM users_web WHERE name = ?",
    [user],
    async (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Ha ocurrido un error en el servidor.");
      }

      if (
        result.length == 0 ||
        !(await bcrypt.compare(pass, result[0].password))
      ) {
        return res.status(401).send("Usuario y/o contraseña incorrecta");
      }

      // Aquí implementamos la lógica para crear una sesión y autentificar al usuario.
      res.send("Disfruta de tu sesión!");
    }
  );
};

/*exports.register es un controlador que se encarga de renderizar la vista "register".
exports.registerPost es un controlador que se encarga de manejar la solicitud HTTP POST cuando un usuario intenta registrarse en la aplicación. 
La función verifica si se han proporcionado valores válidos para los campos "user", "pass" y "mail". Si estos valores son válidos, 
la función hash la contraseña del usuario utilizando la librería "bcryptjs" y luego guarda los datos del usuario en la base de datos.
*/ 
exports.register = (req, res) => {
  res.render("register", { msg: "NPODE" });
};

exports.registerPost = async (req, res) => {
  const user = req.body.user;
  const pass = req.body.pass;
  const mail = req.body.mail;
  const image = req.body.image;

  if (!user || !pass || !mail) {
    return res
      .status(400)
      .send("Debe proporcionar un nombre de usuario, correo electrónico y contraseña.");
  }

  const passwordHash = await bcrypt.hash(pass, 8);

// Agregamos el campo "image" a la tabla users_web, ya que no se había agregado anteriormente y daba un error
// conexion.query(
//   "ALTER TABLE users_web ADD COLUMN image varchar(255) DEFAULT NULL",
//   function (err) {
//     if (err) {
//       console.error(err);
//       return res.status(500).send("Ha ocurrido un error en el servidor.");
//     }
//     console.log("Campo 'image' agregado a la tabla 'users_web'");
//   }
// );

/*La sentencia "INSERT" añade una nueva fila a la tabla "users_web" con los valores especificados en los parámetros "user", "mail", "passwordHash", y "image".*/
/*El método "query" de la conexión ejecuta la sentencia SQL y toma una función callback como tercer argumento. La función callback recibe dos argumentos "err" y "result". 
Si hay un error en la ejecución de la sentencia, "err" contendrá información sobre el error y se devolverá un mensaje de error "Ha ocurrido un error en el servidor." 
con un estado HTTP 500. Si la ejecución es correcta, se imprimirá en la consola "Usuario registrado" y se devolverá un mensaje "Usuario registrado".*/
  conexion.query(
    "INSERT INTO users_web (name, mail, password,image) VALUES (?, ?, ?,?)",
    [user, mail, passwordHash, image],
    function (err, result) {
      if (err) {
        console.error(err);
        return res.status(500).send("Ha ocurrido un error en el servidor.");
      }

      console.log("Usuario registrado");
      res.send("Usuario registrado");
    }
  );
};

/* NO ES FUNCIONAL*/ 
const fs = require('fs');
const Jimp = require('jimp');

exports.convert = (req, res) => {
  const imagePath = req.file.path;

  fs.stat(imagePath, (err, stats) => {
    if (err) {
      if (err.code === 'ENOENT') {
        console.error(`La imagen no existe: ${imagePath}`);
        res.status(404).send(`El archivo no existe: ${imagePath}`);
      } else {
        throw err;
      }
    } else {
      Jimp.read(imagePath)
        .then(image => {
          image
            .quality(100)
            .write(`${imagePath}.png`);
          
            fs.createReadStream(`${imagePath}.png`).pipe(fs.createWriteStream(`C:\\fotos_convertidas\\${req.file.filename}.png`));
            res.sendFile(`${__dirname}/conversor.html`);

            conexion.query('INSERT INTO converted (ruta, fecha) VALUES (?, ?)', [`${imagePath}.png`, new Date()], (err, results) => {
              if (err) {
                console.error(err);
                res.status(500).send('Ha ocurrido un error!');
              } else {
                console.log('El archivo se ha insertado en tu base de datos');
                res.send('El archivo se ha insertado en tu base de datos');
              }
            });
          })
        .catch(err => {
          console.error(err);
          res.status(500).send('Ha ocurrido un error!');
        });
    }
  });
};