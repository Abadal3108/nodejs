const express = require('express');
const router = express.Router();
const Controller = require('../Controller/Controller');

// Ruteo a la página principal
router.get('/', Controller.index);

//Esta ruta está asociada con el método getLogin en el controlador
router.get('/login', Controller.getLogin);
//Esta ruta es para la autenticación de un usuario. Es una petición POST que está asociada con el método postAuth en el controlador.
router.post('/auth', Controller.postAuth);
//Esta ruta es para el registro de un usuario. Hay dos métodos asociados con esta ruta, uno para mostrar la página de registro y otro para procesar la petición de registro.
router.get('/register', Controller.register);
router.post('/register', Controller.registerPost);

module.exports = router;
