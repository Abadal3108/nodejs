
const mysql = require('mysql2');

 /*los valores para conectarse a la base de datos se almacenan como variables de entorno 
 y se accede a ellos a través de process.env*/

const conexion = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: 3306
});

// Función que intenta conectarse a la base de datos
const conectar = () => {
  conexion.connect((error) => {
    if (error) {
      console.error('Error de conexión: ' + error.stack);
      return;
    }
    console.log('Conectado a la base de datos con id de conexión: ' + conexion.threadId);
  });
};

module.exports = conexion;

