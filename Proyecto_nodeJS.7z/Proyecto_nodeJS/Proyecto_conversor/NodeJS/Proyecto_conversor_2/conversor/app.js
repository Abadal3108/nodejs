/*Imports de paquetes y archivos*/
const dotenv = require("dotenv");
dotenv.config();
console.log(process.env);
const express = require("express");
const path = require("path");
const routes = require("./src/routes/routes");
const app = express();
const multer = require("multer"); //procesa los archivos de imagen enviados en la solicitud.
const Controller = require("./src/Controller/Controller");
// Creamos una variable llamada "upload" que utiliza la función "multer" con una destinación de "uploads/"
const upload = multer({ dest: "uploads/" });

// Configuración de la sesión
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Configurar la carpeta de las vistas
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "./src/views"));

// Configuración hoja de estilos
app.use(express.static(path.join(__dirname, "/src/public")));

app.use("/", routes);

/* Manejo de rutas
Asigna una ruta para la página principal que renderiza la vista index.*/
app.route("/").get((req, res) => {
  res.render("index");
});

/* La aplicación escucha una solicitud GET en la ruta raíz "/" y envía un archivo HTML llamado "conversor.html" en la respuesta.
Finalmente, la aplicación escucha una solicitud POST en la ruta "/convert", utilizando el objeto "upload" para procesar un archivo de imagen único enviado en el cuerpo de la solicitud. 
Luego, llama al método "convert" en el objeto "Controller" para la solicitud.

NO ES FUNCIONAL
*/
// app.get("/", (req, res) => {
//   res.sendFile(`${__dirname}/src/views/conversor.html`);
// });

app.post("/convert", upload.single("image"), Controller.convert);

// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
  console.log("Servidor ejecutándose en http://localhost:3000");
});
