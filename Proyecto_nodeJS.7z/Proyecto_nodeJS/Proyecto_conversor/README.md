# Contenido de las carpetas del proyecto Conversor de imágenes y ficheros

En las diferentes carpetas se encuentran los dos diagramas (BBDD y el de clases), el proyecto en node js con dockers , el mockup de nuestra aplicación, el presupuesto y el diagrama de Ganntt.
El proyecto está incompleto, ya que no se ha podido unificar las diversas partes de este, debido a que diversos integrantes
del grupo no han podido realizar su parte del código o no han mostrado interés por realizarlo o intentarlo. Del mismo modo 
el diagrama de Gantt no ha sido modificado por la misma razón.